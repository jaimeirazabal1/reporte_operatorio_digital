/**
 * Modelo <?php echo $class, PHP_EOL ?>
 * 
 * @category App
 * @package Models
 */
class <?php echo $class ?> extends ActiveRecord
{

}