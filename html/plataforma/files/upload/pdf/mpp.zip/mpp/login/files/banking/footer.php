<div class="utility">
            <div class="footerNav containerCentered">
                <nav>
                    <ul class="unstyled list">
                        <li class="hidden-phone"><a href="#">About</a>
                        </li>
                        <li><a href="#">Help</a>
                        </li>
                        <li class="hidden-phone"><a href="#">Rates</a>
                        </li>
                        <li class="hidden-phone"><a href="#">Security</a>
                        </li>
                        <li class="hidden-phone"><a href="#">Developers</a>
                        </li>
                        <li class="hidden-phone"><a href="#">Partners</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="footer containerCentered">
            <div class="footerNav">
                <div class="legal">
                    <p class="copyright">Copyright © 1999 - <?echo date("Y");?> PayPal. All rights reserved.</p>
                    <ul class="unstyled">
                        <li><a href="#">Respect for privacy</a>
                        </li>
                        <li><a href="#">Use contracts</a>
                        </li>
                        <li><a href="#">Updates Regulation</a>
                        </li>
                    </ul>
                    <p class="legalDisc">This content is provided for information purposes only and do not constitute financial or professional advice.</p>
                </div>
            </div>
        </div>