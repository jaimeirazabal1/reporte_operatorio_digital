<?

header("Location: /");

?>