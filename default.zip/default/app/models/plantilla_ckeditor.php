<?php 
class PlantillaCkeditor extends ActiveRecord{
	
}

 ?>